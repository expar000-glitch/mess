import React, { useState } from 'react';
import { AppState, MealLog } from '../types';
import { format, addDays, subDays, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, Check, Minus, PlusCircle, MinusCircle, Settings2, CheckCircle2, XCircle } from 'lucide-react';

const RATE = 53;

interface Props {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const MemberMeals: React.FC<Props> = ({ state, setState }) => {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [bulkMenuOpen, setBulkMenuOpen] = useState(false);

  const getLog = (mid: string) => 
    state.mealLogs.find(l => l.date === date && l.memberId === mid) || 
    { date, memberId: mid, lunch: false, dinner: false, guestLunch: 0, guestDinner: 0 };

  const updateLog = (log: MealLog) => {
    const others = state.mealLogs.filter(l => !(l.date === date && l.memberId === log.memberId));
    setState(prev => ({ ...prev, mealLogs: [...others, log] }));
  };

  const toggle = (mid: string, type: 'lunch' | 'dinner') => {
    const log = getLog(mid);
    updateLog({ ...log, [type]: !log[type] });
  };

  const modGuest = (mid: string, type: 'guestLunch' | 'guestDinner', delta: number) => {
    const log = getLog(mid);
    const val = Math.max(0, log[type] + delta);
    updateLog({ ...log, [type]: val });
  };

  const bulk = (type: 'lunch' | 'dinner', val: boolean) => {
    const others = state.mealLogs.filter(l => l.date !== date);
    const newLogs = state.members.map(m => {
       const existing = state.mealLogs.find(l => l.date === date && l.memberId === m.id);
       if (existing) return { ...existing, [type]: val };
       return { date, memberId: m.id, lunch: false, dinner: false, guestLunch: 0, guestDinner: 0, [type]: val };
    });
    setState(prev => ({ ...prev, mealLogs: [...others, ...newLogs] }));
    setBulkMenuOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row justify-between items-center gap-4 relative">
        <div><h2 className="text-xl font-bold text-slate-800 dark:text-white">Daily Meal Check</h2><p className="text-sm text-slate-500">Mark attendance & guests.</p></div>
        
        <div className="flex gap-4 items-center">
            {/* Bulk Action Dropdown */}
            <div className="relative">
                <button onClick={() => setBulkMenuOpen(!bulkMenuOpen)} className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-medium hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                    <Settings2 size={18} /> Bulk Actions
                </button>
                
                {bulkMenuOpen && (
                    <>
                        <div className="fixed inset-0 z-10" onClick={() => setBulkMenuOpen(false)}></div>
                        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-100 dark:border-slate-700 z-20 overflow-hidden py-1">
                            <button onClick={() => bulk('lunch', true)} className="w-full text-left px-4 py-2 text-sm text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 flex items-center gap-2"><CheckCircle2 size={14}/> Mark All Lunch</button>
                            <button onClick={() => bulk('lunch', false)} className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 flex items-center gap-2"><XCircle size={14}/> Clear All Lunch</button>
                            <div className="h-px bg-slate-100 dark:bg-slate-700 my-1"></div>
                            <button onClick={() => bulk('dinner', true)} className="w-full text-left px-4 py-2 text-sm text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 flex items-center gap-2"><CheckCircle2 size={14}/> Mark All Dinner</button>
                            <button onClick={() => bulk('dinner', false)} className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 flex items-center gap-2"><XCircle size={14}/> Clear All Dinner</button>
                        </div>
                    </>
                )}
            </div>

            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 rounded-xl p-1">
                <button onClick={() => setDate(format(subDays(parseISO(date), 1), 'yyyy-MM-dd'))} className="p-2 hover:bg-white dark:hover:bg-slate-600 rounded-lg"><ChevronLeft size={16} /></button>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-transparent border-none font-bold text-slate-700 dark:text-white text-center w-32 sm:w-36 focus:ring-0" />
                <button onClick={() => setDate(format(addDays(parseISO(date), 1), 'yyyy-MM-dd'))} className="p-2 hover:bg-white dark:hover:bg-slate-600 rounded-lg"><ChevronRight size={16} /></button>
            </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 text-xs uppercase font-bold tracking-wider">
              <tr>
                <th className="p-5">Member</th>
                <th className="p-5 text-center">Lunch</th>
                <th className="p-5 text-center">Dinner</th>
                <th className="p-5 text-center w-48">Guests</th>
                <th className="p-5 text-right">Extra Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
              {state.members.map(m => {
                const log = getLog(m.id);
                // Cost calculation: Personal meals don't show here, only Guests
                const guestCost = (log.guestLunch * RATE) + (log.guestDinner * RATE);
                
                return (
                  <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="p-5 font-bold text-slate-700 dark:text-slate-200">{m.name}</td>
                    <td className="p-5 text-center">
                      <button onClick={() => toggle(m.id, 'lunch')} className="transition-all active:scale-95">
                        {log.lunch 
                          ? <div className="w-8 h-8 mx-auto bg-emerald-500 text-white rounded-lg flex items-center justify-center shadow-md"><Check size={20} /></div> 
                          : <div className="w-8 h-8 mx-auto bg-slate-100 dark:bg-slate-700 text-slate-300 rounded-lg flex items-center justify-center"><Minus size={16} /></div>}
                      </button>
                    </td>
                    <td className="p-5 text-center">
                      <button onClick={() => toggle(m.id, 'dinner')} className="transition-all active:scale-95">
                        {log.dinner 
                          ? <div className="w-8 h-8 mx-auto bg-indigo-500 text-white rounded-lg flex items-center justify-center shadow-md"><Check size={20} /></div> 
                          : <div className="w-8 h-8 mx-auto bg-slate-100 dark:bg-slate-700 text-slate-300 rounded-lg flex items-center justify-center"><Minus size={16} /></div>}
                      </button>
                    </td>
                    <td className="p-5">
                      <div className="flex flex-col gap-2">
                         <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-700/50 rounded-lg p-1 px-2 border border-slate-100 dark:border-slate-600">
                             <span className="text-[10px] font-bold text-slate-400 uppercase">LN</span>
                             <div className="flex items-center gap-2">
                                 <button onClick={() => modGuest(m.id, 'guestLunch', -1)} className="hover:text-rose-500"><MinusCircle size={16}/></button>
                                 <span className="font-bold w-3 text-center text-sm">{log.guestLunch}</span>
                                 <button onClick={() => modGuest(m.id, 'guestLunch', 1)} className="hover:text-emerald-500"><PlusCircle size={16}/></button>
                             </div>
                         </div>
                         <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-700/50 rounded-lg p-1 px-2 border border-slate-100 dark:border-slate-600">
                             <span className="text-[10px] font-bold text-slate-400 uppercase">DN</span>
                             <div className="flex items-center gap-2">
                                 <button onClick={() => modGuest(m.id, 'guestDinner', -1)} className="hover:text-rose-500"><MinusCircle size={16}/></button>
                                 <span className="font-bold w-3 text-center text-sm">{log.guestDinner}</span>
                                 <button onClick={() => modGuest(m.id, 'guestDinner', 1)} className="hover:text-emerald-500"><PlusCircle size={16}/></button>
                             </div>
                         </div>
                      </div>
                    </td>
                    <td className={`p-5 text-right font-bold ${guestCost > 0 ? 'text-rose-600' : 'text-slate-300'}`}>৳ {guestCost}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MemberMeals;