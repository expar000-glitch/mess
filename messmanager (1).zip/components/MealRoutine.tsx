import React, { useState } from 'react';
import { AppState, MealMenu } from '../types';
import { format, parseISO } from 'date-fns';
import { Sun, Moon } from 'lucide-react';

interface Props {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const MealRoutine: React.FC<Props> = ({ state, setState }) => {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  
  const currentMenu = state.menus.find(m => m.date === date) || { lunchMenu: '', dinnerMenu: '' };
  
  const [lunch, setLunch] = useState(currentMenu.lunchMenu);
  const [dinner, setDinner] = useState(currentMenu.dinnerMenu);

  // Sync state when date changes
  React.useEffect(() => {
    const m = state.menus.find(m => m.date === date) || { lunchMenu: '', dinnerMenu: '' };
    setLunch(m.lunchMenu);
    setDinner(m.dinnerMenu);
  }, [date, state.menus]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const otherMenus = state.menus.filter(m => m.date !== date);
    const newMenu: MealMenu = { date, lunchMenu: lunch, dinnerMenu: dinner };
    setState(prev => ({ ...prev, menus: [...otherMenus, newMenu] }));
    alert('Menu updated!');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex items-center justify-between mb-8">
            <div><h2 className="text-2xl font-bold text-slate-800 dark:text-white">Meal Routine</h2><p className="text-slate-500">Plan what to cook.</p></div>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-slate-100 dark:bg-slate-700 border-none rounded-xl px-4 py-2 font-bold text-slate-700 dark:text-white focus:ring-2 focus:ring-blue-500" />
        </div>
        
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-orange-50 dark:bg-orange-900/10 p-6 rounded-2xl border-2 border-orange-100 dark:border-orange-900/30">
                <div className="flex items-center gap-3 mb-4 text-orange-600 dark:text-orange-400"><Sun size={24} /><h3 className="font-bold text-lg">Lunch Menu</h3></div>
                <textarea value={lunch} onChange={e => setLunch(e.target.value)} placeholder="e.g. Rice, Dal..." className="w-full h-32 bg-white dark:bg-slate-800 border-none rounded-xl p-4 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-orange-400 resize-none shadow-sm"></textarea>
            </div>
            <div className="bg-indigo-50 dark:bg-indigo-900/10 p-6 rounded-2xl border-2 border-indigo-100 dark:border-indigo-900/30">
                <div className="flex items-center gap-3 mb-4 text-indigo-600 dark:text-indigo-400"><Moon size={24} /><h3 className="font-bold text-lg">Dinner Menu</h3></div>
                <textarea value={dinner} onChange={e => setDinner(e.target.value)} placeholder="e.g. Roti, Veg..." className="w-full h-32 bg-white dark:bg-slate-800 border-none rounded-xl p-4 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-indigo-400 resize-none shadow-sm"></textarea>
            </div>
            <div className="md:col-span-2">
                <button type="submit" className="w-full py-4 bg-slate-800 hover:bg-slate-900 dark:bg-blue-600 dark:hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg transition-transform hover:scale-[1.01]">
                    Save Menu
                </button>
            </div>
        </form>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
         <h3 className="font-bold text-slate-800 dark:text-white mb-4">Recent Menus</h3>
         <div className="flex gap-4 overflow-x-auto pb-2 custom-scrollbar">
            {state.menus.length === 0 && <p className="text-slate-400 text-sm">No history yet.</p>}
            {state.menus.sort((a,b) => b.date.localeCompare(a.date)).slice(0,5).map(m => (
                <div key={m.date} className="min-w-[200px] p-4 rounded-xl bg-slate-50 dark:bg-slate-700/50 border border-slate-100 dark:border-slate-700 flex flex-col gap-2">
                    <span className="text-xs font-bold text-slate-400 uppercase">{format(parseISO(m.date), 'EEE, MMM dd')}</span>
                    <div><span className="text-[10px] bg-orange-100 text-orange-600 px-1 rounded">L</span> <span className="text-xs text-slate-600 dark:text-slate-300 truncate">{m.lunchMenu || '-'}</span></div>
                    <div><span className="text-[10px] bg-indigo-100 text-indigo-600 px-1 rounded">D</span> <span className="text-xs text-slate-600 dark:text-slate-300 truncate">{m.dinnerMenu || '-'}</span></div>
                </div>
            ))}
         </div>
      </div>
    </div>
  );
};

export default MealRoutine;