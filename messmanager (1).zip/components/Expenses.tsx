import React, { useState, useEffect, useRef } from 'react';
import { AppState, Expense } from '../types';
import { ShoppingCart, PlusCircle, Save, Edit2, Trash2, X, Info } from 'lucide-react';
import { format } from 'date-fns';
import Chart from 'chart.js/auto';

interface Props {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const Expenses: React.FC<Props> = ({ state, setState }) => {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ category: '', item: '', quantity: '', cost: '' });
  const [newCatMode, setNewCatMode] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  const dailyExpenses = state.expenses.filter(e => e.date === date);
  const dailyTotal = dailyExpenses.reduce((s, e) => s + e.cost, 0);

  // Initialize form when editing
  useEffect(() => {
    if (editingId) {
      const exp = state.expenses.find(e => e.id === editingId);
      if (exp) {
        setFormData({
          category: exp.category,
          item: exp.item,
          quantity: exp.quantity,
          cost: exp.cost.toString()
        });
        setDate(exp.date);
      }
    } else {
      setFormData({ category: '', item: '', quantity: '', cost: '' });
    }
  }, [editingId, state.expenses]);

  // Chart Logic
  useEffect(() => {
    if (canvasRef.current) {
      if (chartInstance.current) chartInstance.current.destroy();
      
      const cats = state.customCategories;
      const data = cats.map(c => state.expenses.filter(e => e.category === c).reduce((s, e) => s + e.cost, 0));

      chartInstance.current = new Chart(canvasRef.current, {
        type: 'doughnut',
        data: {
          labels: cats,
          datasets: [{
            data: data,
            backgroundColor: ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6366f1'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { position: 'right' } }
        }
      });
    }
    return () => { if (chartInstance.current) chartInstance.current.destroy(); };
  }, [state.expenses, state.customCategories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cost = parseFloat(formData.cost) || 0;
    let category = formData.category;

    if (newCatMode) {
      if (!state.customCategories.includes(formData.category)) {
        setState(prev => ({ ...prev, customCategories: [...prev.customCategories, formData.category] }));
      }
    }

    if (editingId) {
      setState(prev => ({
        ...prev,
        expenses: prev.expenses.map(ex => ex.id === editingId ? { ...ex, date, category, item: formData.item, quantity: formData.quantity, cost } : ex)
      }));
      setEditingId(null);
    } else {
      const newExp: Expense = {
        id: Date.now().toString(),
        date, category, item: formData.item, quantity: formData.quantity, cost
      };
      setState(prev => ({ ...prev, expenses: [...prev.expenses, newExp] }));
      setFormData(prev => ({ ...prev, item: '', quantity: '', cost: '' })); // Keep category/date
    }
    setNewCatMode(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete expense?')) {
      setState(prev => ({ ...prev, expenses: prev.expenses.filter(e => e.id !== id) }));
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      <div className="xl:col-span-2 space-y-6">
        {/* Form */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 rounded-lg"><ShoppingCart size={24} /></div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">{editingId ? 'Edit Item' : 'Add Daily Shopping'}</h2>
            {editingId && <button onClick={() => setEditingId(null)} className="ml-auto text-sm text-slate-400 hover:text-slate-600 underline">Cancel Edit</button>}
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Category</label>
                {newCatMode ? (
                  <div className="flex gap-2">
                    <input type="text" placeholder="New Category" value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value })} className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
                    <button type="button" onClick={() => setNewCatMode(false)} className="p-3 bg-slate-200 dark:bg-slate-600 rounded-xl"><X size={20} /></button>
                  </div>
                ) : (
                  <select value={formData.category} onChange={e => { if(e.target.value === 'NEW') setNewCatMode(true); else setFormData({...formData, category: e.target.value}); }} required className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white">
                    <option value="" disabled>Select...</option>
                    {state.customCategories.map(c => <option key={c} value={c}>{c}</option>)}
                    <option value="NEW" className="font-bold text-blue-600">+ New Category</option>
                  </select>
                )}
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <input type="text" placeholder="Item Name" value={formData.item} onChange={e => setFormData({ ...formData, item: e.target.value })} required className="bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
              <input type="text" placeholder="Quantity" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} className="bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
              <input type="number" placeholder="Cost (৳)" value={formData.cost} onChange={e => setFormData({ ...formData, cost: e.target.value })} required className="bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white font-bold text-rose-600" />
            </div>
            <button type="submit" className="w-full py-3.5 bg-slate-800 hover:bg-slate-900 dark:bg-blue-600 dark:hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg transition-all flex justify-center items-center gap-2">
              {editingId ? <Save size={20} /> : <PlusCircle size={20} />} {editingId ? 'Update' : 'Add to List'}
            </button>
          </form>
        </div>

        {/* List */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
          <div className="p-4 bg-slate-50 dark:bg-slate-700/30 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
            <span className="font-bold text-slate-700 dark:text-slate-300">Items for {date}</span>
            <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-bold">Total: ৳{dailyTotal}</span>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-700 max-h-[400px] overflow-y-auto">
            {dailyExpenses.length === 0 && <div className="p-8 text-center text-slate-400 italic">No items added.</div>}
            {dailyExpenses.map(e => (
              <div key={e.id} className="p-4 flex justify-between items-center hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                <div>
                  <h4 className="font-bold text-slate-800 dark:text-white">{e.item}</h4>
                  <p className="text-xs text-slate-500">{e.category} • {e.quantity}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-bold text-slate-700 dark:text-slate-200">৳ {e.cost}</span>
                  <div className="flex gap-1">
                    <button onClick={() => setEditingId(e.id)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded"><Edit2 size={16} /></button>
                    <button onClick={() => handleDelete(e.id)} className="p-1.5 text-rose-500 hover:bg-rose-50 rounded"><Trash2 size={16} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 h-80">
          <h3 className="font-bold text-slate-800 dark:text-white mb-4">Category Breakdown</h3>
          <div className="h-60 relative w-full"><canvas ref={canvasRef}></canvas></div>
        </div>
        <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-lg">
          <Info className="w-8 h-8 mb-4 opacity-50" />
          <h3 className="text-xl font-bold mb-2">Did you know?</h3>
          <p className="text-indigo-100 text-sm opacity-80 leading-relaxed">Regularly updating the daily market list helps in tracking exact per-meal costs at the end of the month.</p>
        </div>
      </div>
    </div>
  );
};

export default Expenses;
