import React, { useState, useEffect } from 'react';
import { AppState } from '../types';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';
import { Wallet, TrendingDown, Clock, Calendar, ChevronLeft, ChevronRight, Utensils, ShoppingCart, Users, X, Check, Minus } from 'lucide-react';

interface Props {
  state: AppState;
  darkMode: boolean;
}

const Dashboard: React.FC<Props> = ({ state }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Stats
  // Updated calculation for array based deposits
  const totalDeposit = state.members.reduce((s, m) => {
    const memDep = m.deposits ? m.deposits.reduce((ds, d) => ds + d.amount, 0) : 0;
    return s + memDep;
  }, 0);

  const totalExpense = state.expenses.reduce((s, e) => s + e.cost, 0);
  const balance = totalDeposit - totalExpense;
  
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const todayExpense = state.expenses.filter(e => e.date === todayStr).reduce((s, e) => s + e.cost, 0);
  
  const monthlyCost = state.expenses
    .filter(e => isSameMonth(parseISO(e.date), viewDate))
    .reduce((s, e) => s + e.cost, 0);

  const days = eachDayOfInterval({ start: startOfMonth(viewDate), end: endOfMonth(viewDate) });
  const startPadding = Array(startOfMonth(viewDate).getDay()).fill(null);

  // Modal Data
  const getModalData = () => {
    if (!selectedDate) return null;
    const menu = state.menus.find(m => m.date === selectedDate);
    const exps = state.expenses.filter(e => e.date === selectedDate);
    const total = exps.reduce((s, e) => s + e.cost, 0);
    const logs = state.mealLogs.filter(l => l.date === selectedDate);
    return { menu, exps, total, logs };
  };
  const modalData = getModalData();

  return (
    <div className="space-y-6">
      {/* Top Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-lg shadow-emerald-500/20 transform hover:-translate-y-1 transition-transform">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-emerald-100 text-sm font-medium uppercase tracking-wider">Current Balance</p>
              <h2 className="text-4xl font-bold mt-1">৳ {balance.toLocaleString()}</h2>
            </div>
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm"><Wallet className="w-6 h-6" /></div>
          </div>
          <div className="flex items-center gap-4 text-xs font-medium text-emerald-50 bg-black/10 p-3 rounded-xl">
             <span>Dep: ৳{totalDeposit.toLocaleString()}</span>
             <div className="w-px h-3 bg-emerald-400/50"></div>
             <span>Exp: ৳{totalExpense.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-blue-50 dark:bg-blue-900/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <h3 className="text-5xl font-mono font-bold text-slate-800 dark:text-white tracking-tighter tabular-nums relative z-10">
                {format(currentTime, 'hh:mm:ss')}
                <span className="text-lg text-slate-400 font-sans ml-1">{format(currentTime, 'a')}</span>
            </h3>
            <p className="text-slate-500 dark:text-slate-400 font-medium mt-2 relative z-10">{format(currentTime, 'EEEE, MMMM do, yyyy')}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col justify-between">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-rose-100 dark:bg-rose-900/30 text-rose-600 rounded-lg"><TrendingDown className="w-5 h-5" /></div>
               <span className="font-semibold text-slate-600 dark:text-slate-300">Today's Expense</span>
            </div>
            <div className="mt-4">
               <h3 className="text-3xl font-bold text-slate-800 dark:text-white">৳ {todayExpense.toLocaleString()}</h3>
               <p className="text-sm text-slate-400 mt-1">Total items: {state.expenses.filter(e => e.date === todayStr).length}</p>
            </div>
        </div>
      </div>

      {/* Calendar */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg"><Calendar className="w-5 h-5"/></div>
                <h2 className="text-lg font-bold text-slate-800 dark:text-white">Monthly Overview</h2>
            </div>
            <div className="flex items-center bg-white dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 p-1 shadow-sm">
                <button onClick={() => setViewDate(subMonths(viewDate, 1))} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-md text-slate-500"><ChevronLeft className="w-5 h-5"/></button>
                <span className="w-32 text-center font-bold text-slate-700 dark:text-white select-none">{format(viewDate, 'MMMM yyyy')}</span>
                <button onClick={() => setViewDate(addMonths(viewDate, 1))} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-600 rounded-md text-slate-500"><ChevronRight className="w-5 h-5"/></button>
            </div>
            <div className="px-4 py-2 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-lg font-bold text-sm border border-rose-100 dark:border-rose-900">
                Total Exp: ৳ {monthlyCost.toLocaleString()}
            </div>
        </div>

        <div className="p-6">
            <div className="grid grid-cols-7 gap-2 mb-2">
                {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                    <div key={d} className="text-center text-xs font-bold text-slate-400 uppercase tracking-wider">{d}</div>
                ))}
            </div>
            <div className="grid grid-cols-7 gap-2 lg:gap-3">
                {startPadding.map((_, i) => <div key={`pad-${i}`}></div>)}
                {days.map(day => {
                    const dateStr = format(day, 'yyyy-MM-dd');
                    const isToday = isSameDay(day, new Date());
                    const dayExp = state.expenses.filter(e => e.date === dateStr).reduce((s,e)=>s+e.cost,0);
                    const menu = state.menus.find(m => m.date === dateStr);
                    
                    return (
                        <div 
                            key={dateStr}
                            onClick={() => setSelectedDate(dateStr)}
                            className={`min-h-[120px] md:min-h-[140px] border rounded-xl p-3 flex flex-col cursor-pointer transition-all hover:shadow-lg hover:border-blue-400 group relative overflow-hidden ${
                                isToday ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700' : 'bg-white dark:bg-slate-800/50 border-slate-100 dark:border-slate-700'
                            }`}
                        >
                            <div className="flex justify-between items-center mb-2">
                                <span className={`text-sm font-bold ${isToday ? 'text-blue-600 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300'}`}>{format(day, 'd')}</span>
                                {dayExp > 0 && <span className="text-[10px] font-bold text-rose-500 bg-rose-50 dark:bg-rose-900/20 px-2 py-0.5 rounded-full border border-rose-100 dark:border-rose-900/30">৳{dayExp}</span>}
                            </div>
                            <div className="mt-auto space-y-1.5">
                                {menu ? (
                                    <>
                                        {menu.lunchMenu && <div className="text-[10px] text-slate-500 truncate flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-orange-400"></span>{menu.lunchMenu}</div>}
                                        {menu.dinnerMenu && <div className="text-[10px] text-slate-500 truncate flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>{menu.dinnerMenu}</div>}
                                    </>
                                ) : (
                                    <div className="h-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <div className="w-4 h-4 rounded-full border-2 border-slate-300 dark:border-slate-600"></div>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
      </div>

      {/* Modal */}
      {selectedDate && modalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" onClick={() => setSelectedDate(null)}>
              <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                  <div className="p-5 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                      <div>
                          <h3 className="text-xl font-bold text-slate-800 dark:text-white">{format(parseISO(selectedDate), 'MMMM do, yyyy')}</h3>
                          <p className="text-sm text-slate-500">Daily Summary</p>
                      </div>
                      <button onClick={() => setSelectedDate(null)}><X className="text-slate-400" /></button>
                  </div>
                  <div className="p-6 overflow-y-auto space-y-6">
                      {/* Menu Section */}
                      <div className="grid grid-cols-2 gap-4">
                          <div className="bg-orange-50 dark:bg-orange-900/10 p-4 rounded-xl border border-orange-100 dark:border-orange-900/30">
                              <span className="text-xs font-bold text-orange-600 uppercase flex gap-1"><Utensils size={12}/> Lunch</span>
                              <p className="text-slate-700 dark:text-slate-300 text-sm mt-1">{modalData.menu?.lunchMenu || 'Not set'}</p>
                          </div>
                          <div className="bg-indigo-50 dark:bg-indigo-900/10 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900/30">
                              <span className="text-xs font-bold text-indigo-600 uppercase flex gap-1"><Utensils size={12}/> Dinner</span>
                              <p className="text-slate-700 dark:text-slate-300 text-sm mt-1">{modalData.menu?.dinnerMenu || 'Not set'}</p>
                          </div>
                      </div>

                      {/* Meal Attendance Section */}
                      <div>
                          <h4 className="font-bold text-slate-700 dark:text-white flex gap-2 mb-3"><Users size={16}/> Meal Attendance</h4>
                          <div className="border border-slate-100 dark:border-slate-700 rounded-xl overflow-hidden">
                              <div className="bg-slate-50 dark:bg-slate-800/80 p-2 grid grid-cols-4 gap-2 text-xs font-bold text-slate-500 uppercase">
                                <span>Member</span>
                                <span className="text-center">Lunch</span>
                                <span className="text-center">Dinner</span>
                                <span className="text-center">Guest</span>
                              </div>
                              <div className="divide-y divide-slate-100 dark:divide-slate-700">
                                {state.members.map(m => {
                                  const log = modalData.logs.find(l => l.memberId === m.id);
                                  const hasMeal = log?.lunch || log?.dinner || (log?.guestLunch || 0) > 0 || (log?.guestDinner || 0) > 0;
                                  if (!hasMeal) return null; // Only show members who ate

                                  return (
                                    <div key={m.id} className="p-3 grid grid-cols-4 gap-2 text-sm items-center">
                                      <span className="font-medium text-slate-800 dark:text-white truncate">{m.name}</span>
                                      <div className="flex justify-center">
                                        {log?.lunch ? <div className="bg-emerald-100 text-emerald-600 p-1 rounded-full"><Check size={12}/></div> : <span className="text-slate-300">-</span>}
                                      </div>
                                      <div className="flex justify-center">
                                        {log?.dinner ? <div className="bg-indigo-100 text-indigo-600 p-1 rounded-full"><Check size={12}/></div> : <span className="text-slate-300">-</span>}
                                      </div>
                                      <div className="flex justify-center text-slate-600 dark:text-slate-400">
                                        {(log?.guestLunch || 0) + (log?.guestDinner || 0) > 0 ? (log?.guestLunch||0) + (log?.guestDinner||0) : '-'}
                                      </div>
                                    </div>
                                  );
                                })}
                                {!modalData.logs.some(l => l.lunch || l.dinner || l.guestLunch > 0 || l.guestDinner > 0) && (
                                  <div className="p-4 text-center text-slate-400 text-sm italic">No meals recorded for this day.</div>
                                )}
                              </div>
                          </div>
                      </div>

                      {/* Expenses Section */}
                      <div>
                          <div className="flex justify-between items-center mb-3">
                              <h4 className="font-bold text-slate-700 dark:text-white flex gap-2"><ShoppingCart size={16}/> Shopping List</h4>
                              <span className="text-xs font-bold bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">Total: ৳{modalData.total}</span>
                          </div>
                          <div className="border border-slate-100 dark:border-slate-700 rounded-xl overflow-hidden">
                              {modalData.exps.length === 0 && <div className="p-4 text-center text-slate-400 text-sm">No shopping done.</div>}
                              {modalData.exps.map(e => (
                                  <div key={e.id} className="p-3 border-b border-slate-100 dark:border-slate-700 last:border-0 flex justify-between text-sm">
                                      <span>{e.item} <span className="text-slate-400">({e.quantity})</span></span>
                                      <span className="font-bold dark:text-slate-200">৳{e.cost}</span>
                                  </div>
                              ))}
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Dashboard;