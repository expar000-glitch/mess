import React, { useState } from 'react';
import { AppState, Member, DepositTransaction } from '../types';
import { UserPlus, Edit3, Trash2, X, Save, Plus, History, CreditCard, CalendarX, UserCheck } from 'lucide-react';
import { format, parseISO } from 'date-fns';

const RATE = 53;

interface Props {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const Members: React.FC<Props> = ({ state, setState }) => {
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [viewingMember, setViewingMember] = useState<Member | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'deposits'>('details');
  
  // Member Form State
  const [formData, setFormData] = useState({ name: '', initialDeposit: '' });
  
  // Deposit Form State (Inside Edit Modal)
  const [depositAmount, setDepositAmount] = useState('');
  const [depositDate, setDepositDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  const handleEditClick = (e: React.MouseEvent, member: Member) => {
    e.stopPropagation(); 
    setIsEditing(member.id);
    setFormData({ name: member.name, initialDeposit: '' });
    setActiveTab('details'); // Reset tab
  };

  const handleAddClick = () => {
    setIsEditing('NEW');
    setFormData({ name: '', initialDeposit: '' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing === 'NEW') {
      const initialAmount = parseFloat(formData.initialDeposit);
      const newMember: Member = {
        id: Date.now().toString(),
        name: formData.name,
        deposits: []
      };

      if (!isNaN(initialAmount) && initialAmount > 0) {
        newMember.deposits.push({
          id: Date.now().toString() + '_dep',
          amount: initialAmount,
          date: format(new Date(), 'yyyy-MM-dd')
        });
      }

      setState(prev => ({ ...prev, members: [...prev.members, newMember] }));
      setIsEditing(null);
    } else {
      // Update Name
      setState(prev => ({
        ...prev,
        members: prev.members.map(m => m.id === isEditing ? { ...m, name: formData.name } : m)
      }));
      setIsEditing(null);
    }
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Delete this member and all their data?')) {
      setState(prev => ({
        ...prev,
        members: prev.members.filter(m => m.id !== id),
        mealLogs: prev.mealLogs.filter(l => l.memberId !== id)
      }));
    }
  };

  const handleAddDeposit = () => {
    if (!isEditing || isEditing === 'NEW') return;
    const amount = parseFloat(depositAmount);
    if (!amount) return;

    const newTx: DepositTransaction = {
      id: Date.now().toString(),
      amount: amount,
      date: depositDate
    };

    setState(prev => ({
      ...prev,
      members: prev.members.map(m => m.id === isEditing ? { ...m, deposits: [...m.deposits, newTx] } : m)
    }));
    
    setDepositAmount('');
  };

  const handleDeleteDeposit = (txId: string) => {
    if (!isEditing || isEditing === 'NEW') return;
    if(confirm('Remove this deposit entry?')) {
      setState(prev => ({
        ...prev,
        members: prev.members.map(m => m.id === isEditing ? { ...m, deposits: m.deposits.filter(d => d.id !== txId) } : m)
      }));
    }
  };

  const getMemberStats = (member: Member) => {
    let mealsEaten = 0;
    let mealsOff = 0;
    let guestMeals = 0;
    const offDetails: string[] = [];
    
    state.mealLogs.filter(l => l.memberId === member.id).forEach(l => {
      // Count Lunch
      if(l.lunch) {
        mealsEaten++;
      } else {
        mealsOff++;
      }

      // Count Dinner
      if(l.dinner) {
        mealsEaten++;
      } else {
        mealsOff++;
      }

      // Track dates details for Off Meals
      if (!l.lunch || !l.dinner) {
        const skippedParts = [];
        if (!l.lunch) skippedParts.push('Lunch');
        if (!l.dinner) skippedParts.push('Dinner');
        offDetails.push(`${format(parseISO(l.date), 'MMM dd')} (${skippedParts.join(', ')})`);
      }

      guestMeals += (l.guestLunch + l.guestDinner);
    });
    
    const totalDeposit = member.deposits.reduce((sum, d) => sum + d.amount, 0);
    
    // Cost Logic (Per Meal Basis):
    // Standard Meal Eaten = 0 Tk
    // Guest Meal = +53 Tk
    // Meal Off = -53 Tk (Rebate)
    
    const guestCharge = guestMeals * RATE;
    const offRebate = mealsOff * RATE;
    
    const netCost = guestCharge - offRebate; 
    
    return { mealsEaten, mealsOff, offDetails, guestMeals, totalDeposit, guestCharge, offRebate, netCost };
  };

  const editingMember = isEditing && isEditing !== 'NEW' ? state.members.find(m => m.id === isEditing) : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white">Members Management</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Manage members and deposits.</p>
        </div>
        <button onClick={handleAddClick} className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 shadow-lg shadow-blue-500/20 transition-all active:scale-95">
          <UserPlus size={20} /> Add Member
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {state.members.length === 0 && <div className="col-span-full text-center py-20 text-slate-400">No members found. Add one to get started.</div>}
        {state.members.map(m => {
          const stats = getMemberStats(m);
          const balance = stats.totalDeposit - stats.netCost;

          return (
            <div 
                key={m.id} 
                onClick={() => setViewingMember(m)}
                className="bg-white dark:bg-slate-800 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-700 group hover:border-blue-300 dark:hover:border-blue-500 transition-all relative overflow-hidden cursor-pointer"
            >
                <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2 bg-gradient-to-l from-white dark:from-slate-800 to-transparent pl-8">
                    <button onClick={(e) => handleEditClick(e, m)} className="p-1.5 bg-slate-100 dark:bg-slate-700 text-slate-600 hover:text-blue-600 rounded-lg"><Edit3 size={16}/></button>
                    <button onClick={(e) => handleDelete(e, m.id)} className="p-1.5 bg-rose-50 dark:bg-slate-700 text-rose-500 hover:text-rose-700 rounded-lg"><Trash2 size={16}/></button>
                </div>
                <div className="flex items-center gap-4 mb-5">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-xl shadow-md">
                        {m.name.charAt(0)}
                    </div>
                    <div>
                        <h3 className="font-bold text-lg text-slate-800 dark:text-white">{m.name}</h3>
                        <p className="text-xs font-medium text-slate-400">Click to view stats</p>
                    </div>
                </div>
                <div className="space-y-3 bg-slate-50 dark:bg-slate-700/30 rounded-xl p-3 border border-slate-100 dark:border-slate-700/50">
                    <div className="flex justify-between items-center text-sm"><span className="text-slate-500">Deposit</span><span className="font-bold text-emerald-600">৳ {stats.totalDeposit.toLocaleString()}</span></div>
                    <div className="w-full h-px bg-slate-200 dark:bg-slate-600"></div>
                    <div className="flex justify-between items-center text-sm"><span className="text-slate-500">Balance</span><span className={`font-bold px-2 py-0.5 rounded text-white ${balance >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}>৳ {balance.toFixed(0)}</span></div>
                </div>
            </div>
          );
        })}
      </div>

      {/* Edit/Add Member Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                {/* Header */}
                <div className="flex justify-between items-center p-6 border-b border-slate-100 dark:border-slate-700">
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white">{isEditing === 'NEW' ? 'Add Member' : 'Edit Member'}</h3>
                    <button onClick={() => setIsEditing(null)}><X className="text-slate-400" /></button>
                </div>

                {/* Tabs for Edit Mode */}
                {isEditing !== 'NEW' && (
                  <div className="flex border-b border-slate-100 dark:border-slate-700">
                    <button 
                      onClick={() => setActiveTab('details')}
                      className={`flex-1 py-3 text-sm font-bold ${activeTab === 'details' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'}`}
                    >
                      Profile Info
                    </button>
                    <button 
                      onClick={() => setActiveTab('deposits')}
                      className={`flex-1 py-3 text-sm font-bold ${activeTab === 'deposits' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'}`}
                    >
                      Manage Deposits
                    </button>
                  </div>
                )}

                <div className="p-6 overflow-y-auto">
                  {/* Name Form */}
                  {(isEditing === 'NEW' || activeTab === 'details') && (
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Name</label>
                            <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required placeholder="Enter member name" className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
                        </div>
                        
                        {isEditing === 'NEW' && (
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Initial Deposit</label>
                                <input type="number" value={formData.initialDeposit} onChange={e => setFormData({...formData, initialDeposit: e.target.value})} placeholder="Optional (e.g. 2000)" className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
                            </div>
                        )}

                        <button type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg flex justify-center gap-2">
                            <Save size={20}/> {isEditing === 'NEW' ? 'Create Member' : 'Update Name'}
                        </button>
                    </form>
                  )}

                  {/* Deposit Management (Only in Edit Mode) */}
                  {isEditing !== 'NEW' && activeTab === 'deposits' && editingMember && (
                    <div className="space-y-4">
                       <div className="bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-xl border border-emerald-100 dark:border-emerald-900/30 flex justify-between items-center">
                          <span className="text-sm font-bold text-emerald-800 dark:text-emerald-400">Total Deposited</span>
                          <span className="text-xl font-bold text-emerald-600">৳ {editingMember.deposits.reduce((s,d)=>s+d.amount,0)}</span>
                       </div>

                       <div className="bg-slate-50 dark:bg-slate-700/30 p-4 rounded-xl space-y-3 border border-slate-100 dark:border-slate-700/50">
                          <label className="text-xs font-bold text-slate-500 uppercase">Add New Deposit</label>
                          <div className="flex gap-2">
                              <input type="date" value={depositDate} onChange={e => setDepositDate(e.target.value)} className="w-1/3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
                              <input type="number" placeholder="Amount" value={depositAmount} onChange={e => setDepositAmount(e.target.value)} className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" />
                              <button onClick={handleAddDeposit} className="bg-emerald-500 hover:bg-emerald-600 text-white px-3 rounded-lg"><Plus size={20}/></button>
                          </div>
                       </div>

                       <div className="space-y-2 max-h-48 overflow-y-auto">
                          <label className="text-xs font-bold text-slate-500 uppercase">History</label>
                          {editingMember.deposits.length === 0 && <p className="text-xs text-slate-400 italic">No deposits yet.</p>}
                          {[...editingMember.deposits].sort((a,b) => b.date.localeCompare(a.date)).map(tx => (
                            <div key={tx.id} className="flex justify-between items-center p-3 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-lg text-sm">
                                <span className="text-slate-500">{format(new Date(tx.date), 'dd MMM')}</span>
                                <span className="font-bold text-emerald-600">৳ {tx.amount}</span>
                                <button onClick={() => handleDeleteDeposit(tx.id)} className="text-rose-400 hover:text-rose-600"><Trash2 size={14}/></button>
                            </div>
                          ))}
                       </div>
                    </div>
                  )}
                </div>
            </div>
        </div>
      )}

      {/* View Details Modal (Read Only) */}
      {viewingMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto" onClick={() => setViewingMember(null)}>
              <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-8" onClick={e => e.stopPropagation()}>
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white relative">
                      <button onClick={() => setViewingMember(null)} className="absolute top-4 right-4 text-white/70 hover:text-white"><X size={24}/></button>
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-white text-blue-600 rounded-full flex items-center justify-center text-3xl font-bold shadow-lg">
                            {viewingMember.name.charAt(0)}
                        </div>
                        <div>
                            <h3 className="text-2xl font-bold">{viewingMember.name}</h3>
                            <p className="text-blue-100 text-sm opacity-80">Member Profile</p>
                        </div>
                      </div>
                  </div>
                  
                  <div className="p-6 space-y-6">
                      {(() => {
                          const stats = getMemberStats(viewingMember);
                          const balance = stats.totalDeposit - stats.netCost;
                          return (
                              <>
                                  <div className="grid grid-cols-2 gap-4">
                                      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-900/30 text-center">
                                          <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold mb-1">Total Deposit</p>
                                          <p className="text-2xl font-bold text-emerald-600">৳ {stats.totalDeposit}</p>
                                      </div>
                                      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 text-center">
                                          <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold mb-1">Net Balance</p>
                                          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-blue-600' : 'text-rose-600'}`}>৳ {balance}</p>
                                      </div>
                                  </div>
                                  
                                  <div className="bg-slate-50 dark:bg-slate-700/30 p-5 rounded-xl border border-slate-100 dark:border-slate-700/50">
                                      <h4 className="text-xs font-bold text-slate-500 uppercase mb-4 flex items-center gap-2"><CreditCard size={14}/> Result Calculation</h4>
                                      
                                      <div className="space-y-4">
                                          {/* Standard Meals */}
                                          <div className="flex justify-between items-center text-sm">
                                              <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><UserCheck size={16}/> Total Meals Eaten (0 Tk)</span>
                                              <span className="font-bold bg-slate-200 dark:bg-slate-600 px-2 rounded">{stats.mealsEaten} meals</span>
                                          </div>
                                          
                                          {/* Guest Charge */}
                                          <div className="flex justify-between items-center text-sm">
                                              <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Plus size={16} className="text-rose-500"/> Guest Charge (+৳{RATE})</span>
                                              <div className="text-right">
                                                  <span className="block font-bold text-rose-600">৳ {stats.guestCharge}</span>
                                                  <span className="text-[10px] text-slate-400">{stats.guestMeals} meals</span>
                                              </div>
                                          </div>

                                          {/* Off Rebate */}
                                          <div className="flex justify-between items-center text-sm">
                                              <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><CalendarX size={16} className="text-emerald-500"/> Meal Off Rebate (-৳{RATE})</span>
                                              <div className="text-right">
                                                  <span className="block font-bold text-emerald-600">- ৳ {stats.offRebate}</span>
                                                  <span className="text-[10px] text-slate-400">{stats.mealsOff} meals</span>
                                              </div>
                                          </div>
                                          
                                          <div className="h-px bg-slate-200 dark:bg-slate-600"></div>
                                          
                                          {/* Net Result */}
                                          <div className="flex justify-between items-center font-bold">
                                              <span className="text-slate-700 dark:text-white">Net Result</span>
                                              <span className={`${stats.netCost > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                                                {stats.netCost > 0 ? 'Due ' : 'Saved '} 
                                                ৳ {Math.abs(stats.netCost)}
                                              </span>
                                          </div>
                                      </div>
                                  </div>

                                  {/* Skipped Dates List */}
                                  {stats.offDetails.length > 0 && (
                                    <div className="border border-slate-100 dark:border-slate-700 rounded-xl overflow-hidden">
                                        <div className="bg-slate-50 dark:bg-slate-800 p-3 text-xs font-bold text-slate-500 uppercase border-b border-slate-100 dark:border-slate-700">
                                            Skipped Meals (Rebate Added)
                                        </div>
                                        <div className="p-3 max-h-32 overflow-y-auto flex flex-col gap-2">
                                            {stats.offDetails.sort().map((d, i) => (
                                                <div key={i} className="text-xs flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                                    {d}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                  )}
                              </>
                          );
                      })()}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Members;