import React, { useEffect, useRef, useState } from 'react';
import { AppState } from '../types';
import { Printer, Calendar, X, ShoppingCart, ChevronLeft, ChevronRight } from 'lucide-react';
import Chart from 'chart.js/auto';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';

const RATE = 53;

interface Props {
  state: AppState;
  darkMode: boolean;
}

const Reports: React.FC<Props> = ({ state, darkMode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const stats = state.members.map(m => {
    let mealsEaten = 0;
    let mealsOff = 0;
    let guests = 0;
    
    state.mealLogs.filter(l => l.memberId === m.id).forEach(l => {
        // Check Lunch
        if(l.lunch) mealsEaten++;
        else mealsOff++;

        // Check Dinner
        if(l.dinner) mealsEaten++;
        else mealsOff++;

        guests += (l.guestLunch + l.guestDinner);
    });

    const guestCharge = guests * RATE;
    const offRebate = mealsOff * RATE;
    // Net Cost to user = Extra Charges - Savings
    const netCost = guestCharge - offRebate;
    
    const totalDeposit = m.deposits ? m.deposits.reduce((sum, d) => sum + d.amount, 0) : 0;
    const balance = totalDeposit - netCost;
    
    return { ...m, mealsEaten, mealsOff, guests, netCost, totalDeposit, balance };
  });

  const grandTotalDeposit = stats.reduce((s, m) => s + m.totalDeposit, 0);
  const grandTotalExpense = state.expenses.reduce((s, e) => s + e.cost, 0);

  // Calendar Data
  const days = eachDayOfInterval({ start: startOfMonth(viewDate), end: endOfMonth(viewDate) });
  const startPadding = Array(startOfMonth(viewDate).getDay()).fill(null);
  
  const getSelectedExpenses = () => {
      if(!selectedDate) return [];
      return state.expenses.filter(e => e.date === selectedDate);
  };
  const selectedExpenses = getSelectedExpenses();
  const selectedTotal = selectedExpenses.reduce((s,e) => s+e.cost, 0);

  useEffect(() => {
    if (canvasRef.current) {
      if (chartInstance.current) chartInstance.current.destroy();

      chartInstance.current = new Chart(canvasRef.current, {
        type: 'bar',
        data: {
          labels: stats.map(s => s.name),
          datasets: [
            { label: 'Deposit', data: stats.map(s => s.totalDeposit), backgroundColor: '#10b981', borderRadius: 4 },
            { label: 'Net Result', data: stats.map(s => s.netCost), backgroundColor: '#6366f1', borderRadius: 4 }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
             y: { beginAtZero: true, grid: { color: darkMode ? '#334155' : '#e2e8f0' }, ticks: { color: darkMode ? '#94a3b8' : '#64748b' } },
             x: { grid: { display: false }, ticks: { color: darkMode ? '#94a3b8' : '#64748b' } }
          },
          plugins: { legend: { labels: { color: darkMode ? '#94a3b8' : '#475569' } } }
        }
      });
    }
    return () => { if (chartInstance.current) chartInstance.current.destroy(); };
  }, [stats, darkMode]);

  return (
    <div className="space-y-8">
      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <h3 className="text-slate-500 uppercase text-sm font-semibold">Total Deposits</h3>
            <p className="text-3xl font-bold text-emerald-600 mt-2">৳ {grandTotalDeposit.toLocaleString()}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <h3 className="text-slate-500 uppercase text-sm font-semibold">Total Bazaar Cost</h3>
            <p className="text-3xl font-bold text-rose-600 mt-2">৳ {grandTotalExpense.toLocaleString()}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
            <h3 className="text-slate-500 uppercase text-sm font-semibold">Cash In Hand</h3>
            <p className="text-3xl font-bold text-blue-600 mt-2">৳ {(grandTotalDeposit - grandTotalExpense).toLocaleString()}</p>
        </div>
      </div>

      {/* Shopping Calendar */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-2">
                <ShoppingCart className="text-blue-600" size={20} />
                <h2 className="text-lg font-bold text-slate-800 dark:text-white">Shopping History</h2>
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-700 rounded-lg border p-1">
                <button onClick={() => setViewDate(subMonths(viewDate, 1))} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-600 rounded"><ChevronLeft size={16}/></button>
                <span className="text-sm font-bold min-w-[100px] text-center">{format(viewDate, 'MMMM yyyy')}</span>
                <button onClick={() => setViewDate(addMonths(viewDate, 1))} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-600 rounded"><ChevronRight size={16}/></button>
            </div>
        </div>
        <div className="p-6">
            <div className="grid grid-cols-7 gap-2 mb-2">
                {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                    <div key={d} className="text-center text-xs font-bold text-slate-400 uppercase">{d}</div>
                ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
                {startPadding.map((_, i) => <div key={`pad-${i}`}></div>)}
                {days.map(day => {
                    const dateStr = format(day, 'yyyy-MM-dd');
                    const exp = state.expenses.filter(e => e.date === dateStr).reduce((s,e)=>s+e.cost,0);
                    return (
                        <div 
                            key={dateStr}
                            onClick={() => setSelectedDate(dateStr)}
                            className={`min-h-[80px] border rounded-lg p-2 flex flex-col cursor-pointer transition-all hover:border-blue-500 ${exp > 0 ? 'bg-rose-50 dark:bg-rose-900/10 border-rose-100 dark:border-rose-900/30' : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700'}`}
                        >
                            <span className={`text-xs font-bold mb-1 ${isSameDay(day, new Date()) ? 'text-blue-600' : 'text-slate-500'}`}>{format(day, 'd')}</span>
                            {exp > 0 && <span className="mt-auto text-xs font-bold text-rose-600 bg-white dark:bg-slate-800 px-1 py-0.5 rounded shadow-sm self-start">৳{exp}</span>}
                        </div>
                    );
                })}
            </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Monthly Summary</h2>
            <button onClick={() => window.print()} className="flex items-center gap-2 text-sm font-bold text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-700 px-3 py-1.5 rounded-lg transition-colors">
                <Printer size={16} /> Print Report
            </button>
        </div>
        
        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
            <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-600 dark:text-slate-300 font-bold uppercase text-xs">
                    <tr>
                        <th className="p-4">Member</th>
                        <th className="p-4 text-center">Meals Eaten</th>
                        <th className="p-4 text-center">Meals Skipped</th>
                        <th className="p-4 text-center">Guests</th>
                        <th className="p-4 text-right">Net Cost (Charge - Rebate)</th>
                        <th className="p-4 text-right">Deposit</th>
                        <th className="p-4 text-right">Balance</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                    {stats.map(s => (
                        <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                            <td className="p-4 font-bold text-slate-700 dark:text-slate-200">{s.name}</td>
                            <td className="p-4 text-center text-slate-500 dark:text-slate-400">{s.mealsEaten}</td>
                            <td className="p-4 text-center text-emerald-600 dark:text-emerald-400 font-medium">{s.mealsOff}</td>
                            <td className="p-4 text-center text-slate-500 dark:text-slate-400">{s.guests}</td>
                            <td className={`p-4 text-right font-bold ${s.netCost > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>৳ {s.netCost.toLocaleString()}</td>
                            <td className="p-4 text-right font-bold text-emerald-600">৳ {s.totalDeposit.toLocaleString()}</td>
                            <td className="p-4 text-right">
                                <span className={`px-2 py-1 rounded text-xs font-bold ${s.balance >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                                    {s.balance >= 0 ? '+' : ''}৳ {s.balance.toLocaleString()}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="font-bold text-slate-800 dark:text-white mb-6">Visual Overview</h3>
        <div className="h-[400px]">
            <canvas ref={canvasRef}></canvas>
        </div>
      </div>

      {/* Expense Detail Modal */}
      {selectedDate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" onClick={() => setSelectedDate(null)}>
              <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
                  <div className="p-4 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800">
                      <h3 className="font-bold text-lg dark:text-white">{format(parseISO(selectedDate), 'MMMM do, yyyy')}</h3>
                      <button onClick={() => setSelectedDate(null)}><X className="text-slate-400"/></button>
                  </div>
                  <div className="p-4">
                      {selectedExpenses.length === 0 ? (
                          <p className="text-center text-slate-400 py-4">No shopping records found.</p>
                      ) : (
                          <div className="space-y-3">
                              {selectedExpenses.map(e => (
                                  <div key={e.id} className="flex justify-between items-center p-3 border border-slate-100 dark:border-slate-700 rounded-lg">
                                      <div>
                                          <p className="font-bold text-slate-800 dark:text-white">{e.item}</p>
                                          <p className="text-xs text-slate-500">{e.category} • {e.quantity}</p>
                                      </div>
                                      <span className="font-bold text-rose-600">৳ {e.cost}</span>
                                  </div>
                              ))}
                              <div className="border-t border-slate-100 dark:border-slate-700 pt-3 flex justify-between font-bold text-lg">
                                  <span className="dark:text-white">Total</span>
                                  <span className="text-rose-600">৳ {selectedTotal}</span>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Reports;