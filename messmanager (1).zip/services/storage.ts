import { AppState, DEFAULT_STATE } from '../types';

const STORAGE_KEY = 'mess_manager_react_v1';

export const loadState = (): AppState => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      
      // Migration: Convert old 'deposit' number to 'deposits' array if needed
      if (parsed.members && parsed.members.length > 0 && typeof parsed.members[0].deposit === 'number') {
        parsed.members = parsed.members.map((m: any) => ({
          ...m,
          deposits: [{ id: Date.now().toString(), amount: m.deposit || 0, date: new Date().toISOString().split('T')[0] }]
        }));
      }

      return { ...DEFAULT_STATE, ...parsed };
    }
  } catch (e) {
    console.error('Failed to load state', e);
  }
  return DEFAULT_STATE;
};

export const saveState = (state: AppState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save state', e);
  }
};