export interface DepositTransaction {
  id: string;
  amount: number;
  date: string;
}

export interface Member {
  id: string;
  name: string;
  deposits: DepositTransaction[];
}

export interface Expense {
  id: string;
  date: string;
  category: string;
  item: string;
  quantity: string;
  cost: number;
}

export interface MealLog {
  date: string;
  memberId: string;
  lunch: boolean;
  dinner: boolean;
  guestLunch: number;
  guestDinner: number;
}

export interface MealMenu {
  date: string;
  lunchMenu: string;
  dinnerMenu: string;
}

export interface AppState {
  members: Member[];
  expenses: Expense[];
  mealLogs: MealLog[];
  menus: MealMenu[];
  customCategories: string[];
}

export const DEFAULT_STATE: AppState = {
  members: [],
  expenses: [],
  mealLogs: [],
  menus: [],
  customCategories: ['Rice/Pulse', 'Vegetables', 'Fish/Meat', 'Oil/Spices', 'Potato/Onion', 'Gas', 'Utility']
};