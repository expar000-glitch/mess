import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Users, ShoppingBag, 
  UtensilsCrossed, CheckSquare, BarChart3, 
  Sun, Moon, Menu, X, LogOut 
} from 'lucide-react';
import { AppState, DEFAULT_STATE } from './types';
import { loadState, saveState } from './services/storage';

// Components
import Dashboard from './components/Dashboard';
import Members from './components/Members';
import Expenses from './components/Expenses';
import MealRoutine from './components/MealRoutine';
import MemberMeals from './components/MemberMeals';
import Reports from './components/Reports';

function App() {
  const [state, setState] = useState<AppState>(DEFAULT_STATE);
  const [activeTab, setActiveTab] = useState('home');
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  // Load initial state
  useEffect(() => {
    const loaded = loadState();
    setState(loaded);
    
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
    setLoading(false);
  }, []);

  // Save state on change
  useEffect(() => {
    if (!loading) {
      saveState(state);
    }
  }, [state, loading]);

  // Toggle Theme
  const toggleTheme = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    if (newMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const navItems = [
    { id: 'home', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'shopping', label: 'Daily Shopping', icon: ShoppingBag },
    { id: 'routine', label: 'Meal Routine', icon: UtensilsCrossed },
    { id: 'attendance', label: 'Member Meal', icon: CheckSquare },
    { id: 'reports', label: 'Monthly Report', icon: BarChart3 },
  ];

  if (loading) return <div className="min-h-screen flex items-center justify-center dark:bg-slate-900 dark:text-white">Loading...</div>;

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-900 transition-colors duration-300 font-sans">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 h-screen sticky top-0 z-10">
        <div className="p-6 border-b border-slate-100 dark:border-slate-700">
          <h1 className="text-2xl font-black bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">MessManager</h1>
          <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider">Professional</p>
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium ${
                activeTab === item.id
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-100 dark:border-slate-700">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-slate-100 dark:bg-slate-700/50 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
          >
            {darkMode ? <Moon size={18} /> : <Sun size={18} />}
            <span className="text-sm font-medium">{darkMode ? 'Dark Mode' : 'Light Mode'}</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header & Overlay */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header className="lg:hidden bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 p-4 flex justify-between items-center z-20 sticky top-0">
          <h1 className="text-lg font-bold text-blue-600 dark:text-blue-400">MessManager</h1>
          <div className="flex gap-2">
            <button onClick={toggleTheme} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
              {darkMode ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <button onClick={() => setMobileMenuOpen(true)} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
              <Menu size={20} />
            </button>
          </div>
        </header>

        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)}>
            <div className="absolute top-0 right-0 h-full w-64 bg-white dark:bg-slate-800 shadow-2xl p-4 flex flex-col gap-2" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-6">
                <span className="font-bold text-slate-800 dark:text-white">Menu</span>
                <button onClick={() => setMobileMenuOpen(false)}><X className="text-slate-500" /></button>
              </div>
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium ${
                    activeTab === item.id ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <item.icon size={20} />
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar relative">
          <div className="max-w-7xl mx-auto pb-20">
            {activeTab === 'home' && <Dashboard state={state} darkMode={darkMode} />}
            {activeTab === 'members' && <Members state={state} setState={setState} />}
            {activeTab === 'shopping' && <Expenses state={state} setState={setState} />}
            {activeTab === 'routine' && <MealRoutine state={state} setState={setState} />}
            {activeTab === 'attendance' && <MemberMeals state={state} setState={setState} />}
            {activeTab === 'reports' && <Reports state={state} darkMode={darkMode} />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
